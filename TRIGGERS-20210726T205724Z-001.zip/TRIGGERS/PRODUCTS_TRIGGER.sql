---TRIGGERS------
---CREATE TABLE TO STORE LOGS-----
CREATE TABLE PRODUCTS_AUDITS(
change_id int IDENTITY PRIMARY KEY,
product_id int NOT NULL,
product_name VARCHAR(200) NOT NULL,
brand_id INT NOT NULL,
category_id INT NOT NULL,
model_year SMALLINT NOT NULL,
list_price DECIMAL(10,2) NOT NULL,
updated_at DATETIME NOT NULL,
operation CHAR(3) NOT NULL,
CHECK(operation='INS'or operation='DEL')
)
-----CREATE TRIGGER------
CREATE TRIGGER TRG_PRODUCT_AUDIT
ON PRODUCTS
AFTER INSERT,DELETE
AS
BEGIN 
INSERT INTO PRODUCTS_AUDITS(product_id,product_name,brand_id,category_id,model_year,list_price,updated_at,operation)
SELECT I.product_id,I.product_name,I.brand_id,I.category_id,I.model_year,I.list_price, GETDATE(),'INS' FROM inserted I
UNION ALL
SELECT D.product_id,D.product_name,D.brand_id,D.category_id,D.model_year,D.list_price,GETDATE(),'DEL' FROM DELETED D
END
----TEST TRIGGER-----
INSERT INTO PRODUCTS(product_name,brand_id,category_id,model_year,list_price)
VALUES('PRODUCT33',2,2,2020,700)

SELECT * FROM PRODUCTS_AUDITS

DELETE FROM PRODUCTS WHERE product_id=325

SELECT * FROM PRODUCTS_AUDITS