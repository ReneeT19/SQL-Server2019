----CREATE AUDIT TABLE---
CREATE TABLE CUSTOMER_AUDITS(
change_id int IDENTITY PRIMARY KEY,
customer_id	int NOT NULL,
first_name varchar(255) NOT NULL,
last_name varchar(255) NOT NULL,
phone	varchar(25) NULL,
email varchar(255) NOT NULL,
street varchar(255) NULL,
city varchar(50) NULL,
state varchar(25) NULL,
zip_code varchar(5) NULL,
updated_at datetime,
operation varchar(10)
)
---CREATE TRIGGER FOR CUSTOMER---
CREATE TRIGGER TRG_CUSTOMER_AUDITS
ON CUSTOMERS
AFTER INSERT,DELETE
AS
BEGIN
INSERT INTO CUSTOMER_AUDITS(customer_id,first_name,last_name,phone,email,street,city,state,zip_code,updated_at,operation)
SELECT I.customer_id,I.first_name,I.last_name,I.phone,I.email,I.street,I.city,I.state,I.zip_code,GETDATE(),'INSERTED' FROM inserted I
UNION ALL
SELECT D.customer_id,D.first_name,D.last_name,D.phone,D.email,D.street,D.city,D.state,D.zip_code,GETDATE(),'DELETED' FROM deleted D
END
----TEST TRIGGER---
INSERT INTO CUSTOMERS(first_name,last_name,phone,email,street,city,state,zip_code)
values('scott','tiger','234-343443','scott@gmail.com','dfds','dfds','xyz','23434')

SELECT * FROM CUSTOMER_AUDITS 

DELETE FROM CUSTOMERS WHERE customer_id=1446

SELECT * FROM CUSTOMER_AUDITS 